/*
 * MetisTest.cpp
 *
 *  Created on: Nov 28, 2016
 *      Author: xiangzhang
 */

#include <cstddef>
#include <iostream>
#include <metis.h>
#include <sstream>
#include <vector>
#include <math.h>
#include <string>
#include <algorithm>
#include <fstream>

#include "MetisNode.h"
#include "AdjTable.h"
#include "bitstring.h"
#include "NeighbourListNonSorted.h"
#include "bitstring_reader.h"
#include "bitstring_writer.h"
#include "elias.h"
#include "IndexStructure.h"

using namespace std;

struct BstNode {
	vector <string> EdgeSparators;
	BstNode* left;
	BstNode* right;
	int ** mappingOrg;
	int VertexId;
	int NewVertexId;
	int flag; // "1" is internal node and "0" is leaf node.
	int vertexNum; // number of vertex under the current node
	vector <int> leaves; // set of leaves under current node
	vector <string> EdgeSet; // set for making child fliping
};
// Function to create a new Node in heap
BstNode* GetNewNode(vector <string> EdgeSparator , int num) {
	BstNode* newNode = new BstNode();
	newNode->EdgeSparators = EdgeSparator;
	newNode->vertexNum = num;
	newNode->left = newNode->right = NULL;
	newNode->mappingOrg = NULL;
	newNode->flag = 1;
	newNode->VertexId = -1;
	newNode->NewVertexId = -1;
	return newNode;
}

BstNode* GetLeafNode( int id){
	BstNode* newNode = new BstNode();
	newNode->flag = 0;
	newNode->left = newNode->right = NULL;
	newNode->VertexId = id;
	newNode->NewVertexId = -1;
	newNode->mappingOrg = NULL;
	newNode->vertexNum = 1;
	return newNode;
}

BstNode * root = NULL;
int InorderTraversalVID = 0;
int *mapAfterRenumber = NULL;
vector< vector<string> > adjTable;  //Store the gamma code of
NeighbourListNonSorted nlns; // initialize the neighbour list without sorting
IndexStructure index ; // initialize the index structure which includes direct, semi-direct and indirect index structure



//vector<phsim::BitString::Word> inputWV;
vector< vector<phsim::BitString::Word> > inputWV;
vector<int> offsetIndex;


//idx_t nV = 15;  //


idx_t nV = 15606;  // nV of 4elt.graph
idx_t nE = 45878;  // nE of 4elt.graph

//idx_t nV = 214765;  // nV of m14b.graph
//idx_t nE = 1679018;  // 2*nE of m14b.graph

//idx_t nV = 143437;  // nV of feocean.graph
//idx_t nE = 819186;  // 2*nE of feocean.graph


idx_t * Inputadj = new int [91756];  // size of adj of 4elt graph
idx_t * InputXadj = new int [15607]; // nV of 4elt + 1

//idx_t * Inputadj = new int [3358036];  // size of adj of m14b graph
//idx_t * InputXadj = new int [214766]; // nV of m14b + 1

//idx_t * Inputadj = new int [819186];  // size of adj of feocean graph
//idx_t * InputXadj = new int [143438]; // nV of feocean + 1

bool *negativeDiff = new bool [nV];


int MetisUsage();
string IntToString1 (int a);
BstNode * GenerateTree ( idx_t nVertex , idx_t *xadj, idx_t *adj , int ** mapOrg);
BstNode * GenerateLeaves (idx_t nVertex , idx_t *xadj, idx_t *adj, int ** mapOrg);
void InorderTraversal(BstNode* x);
void PreorderTraversal(BstNode* x);
void RenumberByInorderTraversal(BstNode* x);

void FindNeighbour(BstNode * x);
void FormAdjTable(NeighbourListNonSorted x );
void ReadInput();

void CountLeaves ( BstNode* node , vector<int> &set);
void PreorderTraCountLeaf(BstNode* x);
void PreorderTraversalCheckLeaf(BstNode* x);
void PreorderTraFormEdgeSet(BstNode* x , vector <string> set);
void PreorderTraversalCheckEdgeSet(BstNode* x);
void ChildFliping( BstNode* node);

int main() {

	idx_t nVertices = 15;
	idx_t nEdges    = 22;
    idx_t xadj[nVertices+1] = {0, 2, 5, 8, 11, 13, 16, 20, 24, 28,31, 33, 36, 39, 42, 44};
    idx_t adjncy[2*nEdges] = {1,5,0, 2, 6, 1, 3, 7, 2, 4, 8, 3, 9, 0, 6, 10, 1, 5, 7, 11, 2, 6, 8, 12, 3, 7, 9, 13, 4, 8, 14, 5,
        		11, 6, 10, 12, 7, 11, 13, 8, 12, 14, 9, 13};



	ReadInput();
	cout << "Read input completed" <<endl;
    int ** FirstRound = NULL;
    mapAfterRenumber = new int[nV];
    //GenerateTree(nVertices , xadj , adjncy , FirstRound );
    GenerateTree(nV , InputXadj , Inputadj , FirstRound );
    cout << "Generating separator tree completed" <<endl;

    /*
    PreorderTraCountLeaf(root);
    PreorderTraFormEdgeSet( root->left , root->EdgeSparators);
    PreorderTraFormEdgeSet( root->right , root->EdgeSparators);
    cout << "Making leaf set and edge set completed !" <<endl;
    ChildFliping( root->left);
    cout << "Fliping half completed !" <<endl;
    ChildFliping( root->right);
    cout << "Child Fliping completed ! " <<endl;
	*/

    RenumberByInorderTraversal(root);
    cout << "Renumber completed ! " <<  endl;

    FindNeighbour(root);
    nlns.SortItself();
    FormAdjTable(nlns);
    cout<< "Forming adj table completed ! " <<endl;
    //PreorderTraversal(root);


	phsim::BitString data;
	{
		phsim::BitStringWriter writer(data);
		unsigned int curBitN = 0;
		for (int i=0; i< inputWV.size() ; i++){
			index.directIndex.push_back(curBitN);
			for(auto x:inputWV[i]){
				phsim::gammaEncode(writer ,x ,curBitN );
			}

		}
	}
    cout<< "Gamma Encoding completed ! " <<endl;
    cout<< data.data.size() <<endl;

    index.CountDITotalBits();
    cout << index.directIndexTotalBit <<endl;

    index.BuildSemiDIndex();
    cout << index.semiDIflag <<endl;
    cout << "first word size  : " << index.semiDIFW.size() << endl;

    cout << "second word fit size  :  " << index.semiDISW.size() <<endl;
    cout << "second word not fit size  : " << index.semiDISWSub.size() <<endl;


    /*
	for(auto i : output){
		std::cout<<i<<std::endl;
	}*/

    /*
    for ( int i=0; i< nVertices ; i++){
    	cout << i<< " : "<<mapAfterRenumber[i] << endl;;
    }
    for ( int i=0; i< nVertices ; i++){
      	nlns.PrintItemsInIndex(i);

    }
    cout <<endl;
    for(int i = 0; i<15 ;i++){
    	cout << i << " : " ;
    	for(int j=0; j<nlns.NumberOfItemsInIndex(i); j++){
    		cout<< nlns.sortedNeighbourTable[i][j]<< " ";
    	}
    	cout<<endl;
    } */

	delete FirstRound;
	delete mapAfterRenumber;
	delete root;

	FirstRound = NULL;
	mapAfterRenumber = NULL;
	root = NULL;

    return 0;
}

string IntToString1 (int a){
    ostringstream temp;
    temp<<a;
    return temp.str();
}

void ReadInput(){
	string line, line2;
	//ifstream myfile1 ("/home/xiangzhang/MetisTestGraph/m14b/m14bXadj.txt");  // Reading data of m14b graph
	//ifstream myfile2 ("/home/xiangzhang/MetisTestGraph/m14b/m14bAdj.txt");
	//ifstream myfile1 ("/home/xiangzhang/MetisTestGraph/feocean/feoceanXadj.txt");  // Reading data of feocean
	//ifstream myfile2 ("/home/xiangzhang/MetisTestGraph/feocean/feoceanAdj.txt");
	ifstream myfile1 ("/home/xiangzhang/MetisTestGraph/4elt_xadj.txt");  // Reading data of 4elt
	ifstream myfile2 ("/home/xiangzhang/MetisTestGraph/4elt_adj.txt");


	if (myfile1.is_open()){
		int pos = 0;
		while ( getline (myfile1,line) )
		{
			InputXadj[pos] = stoi(line);
			pos ++ ;
		}
		myfile1.close();
		//cout << pos <<endl;

	}

	else cout << "Unable to open file";

	if (myfile2.is_open()){
		int pos2 = 0;
		while ( getline (myfile2,line2) )
		{
			Inputadj[pos2] = stoi(line2);
			pos2 ++ ;
		}
		myfile2.close();
		//cout << pos2<<endl;
	}
	else cout << "Unable to open file";


}

BstNode * GenerateLeaves (idx_t nVertex , idx_t *xadjancy, idx_t *adjancy , int ** mapOrg){
	//BstNode * topNode = NULL;

	if( nVertex == 3){
		//case1: xadj = {0,1,3,4} adj= {1,0,2,1}
		if ( xadjancy[0]==0 && xadjancy[1]==1 && xadjancy[2]==3 && xadjancy[3]== 4 ){
			//string str1 = "0,1";
			//string str2 = "1,2";
			/*
			if(mapOrg[0][0]==23 ||mapOrg[1][0]==23 ||mapOrg[2][0]==23){
				cout << "case1"<<endl;
			}*/

			string str1 = IntToString1(mapOrg[0][0])+ "," + IntToString1(mapOrg[1][0]);
			string str2 = IntToString1(mapOrg[1][0])+ "," + IntToString1(mapOrg[2][0]);
			vector<string> v1;
			vector<string> v2;
			v1.push_back(str1);
			v2.push_back(str2);
			BstNode * topNode = GetNewNode(v1,3);
			BstNode * leftChild = GetNewNode(v2,2);
			BstNode * leafOne = GetLeafNode(mapOrg[0][0]);
			BstNode * leafTwo = GetLeafNode(mapOrg[1][0]);
			BstNode * leafThree = GetLeafNode(mapOrg[2][0]);
			topNode->left = leftChild;
			topNode->right = leafOne;
			leftChild->left = leafTwo;
			leftChild->right = leafThree;

			return topNode;

		}else if(xadjancy[0]==0 && xadjancy[1]==1 && xadjancy[2]==2 && xadjancy[3]== 4){ //case2: xadj = {0,1,2,4} adj = {2,2,0,1}

			//string str1 = "0,2";
			//string str2 = "1,2";
			/*
			if(mapOrg[0][0]==23 ||mapOrg[1][0]==23 ||mapOrg[2][0]==23){
				cout << "case2"<<endl;
			}*/


			string str1 = IntToString1(mapOrg[0][0])+ "," + IntToString1(mapOrg[2][0]);
			string str2 = IntToString1(mapOrg[1][0])+ "," + IntToString1(mapOrg[2][0]);
			vector<string> v1;
			vector<string> v2;
			v1.push_back(str1);
			v2.push_back(str2);
			BstNode * topNode = GetNewNode(v1,3);
			BstNode * leftChild = GetNewNode(v2,2);
			BstNode * leafOne = GetLeafNode(mapOrg[0][0]);
			BstNode * leafTwo = GetLeafNode(mapOrg[1][0]);
			BstNode * leafThree = GetLeafNode(mapOrg[2][0]);
			topNode->left = leftChild;
			topNode->right = leafOne;
			leftChild->left = leafTwo;
			leftChild->right = leafThree;

			return topNode;

		}else if(xadjancy[0]==0 && xadjancy[1]==2 && xadjancy[2]==3 && xadjancy[3]== 4){ //case3: xadj = {0,2,3,4} adj = {1,2,0,0}
			//string str1 = "0,1";
			//string str2 = "0,2";
			/*
			if(mapOrg[0][0]==23 ||mapOrg[1][0]==23 ||mapOrg[2][0]==23){
				cout << "case3"<<endl;
			}*/
			string str1 = IntToString1(mapOrg[0][0])+ "," + IntToString1(mapOrg[1][0]);
			string str2 = IntToString1(mapOrg[0][0])+ "," + IntToString1(mapOrg[2][0]);
			vector<string> v1;
			vector<string> v2;
			v1.push_back(str1);
			v2.push_back(str2);
			BstNode * topNode = GetNewNode(v1,3);
			BstNode * leftChild = GetNewNode(v2,2);
			BstNode * leafOne = GetLeafNode(mapOrg[1][0]);
			BstNode * leafTwo = GetLeafNode(mapOrg[0][0]);
			BstNode * leafThree = GetLeafNode(mapOrg[2][0]);
			topNode->right = leafOne;
			topNode->left = leftChild;
			leftChild->left = leafTwo;
			leftChild->right = leafThree;

			return topNode;
		}else if(xadjancy[0]==0 && xadjancy[1]==2 && xadjancy[2]==4 && xadjancy[3]== 6){ //case4: xadj = {0,2,4,6} adj = {1,2,0,2,0,1}
			//string str1 = "0,1";
			//string str2 = "0,2";
			//string str3 = "1,2";
			/*
			if(mapOrg[0][0]==23 ||mapOrg[1][0]==23 ||mapOrg[2][0]==23){
				cout << "case4"<<endl;
			}*/
			string str1 = IntToString1(mapOrg[0][0])+ "," + IntToString1(mapOrg[1][0]);
			string str2 = IntToString1(mapOrg[0][0])+ "," + IntToString1(mapOrg[2][0]);
			string str3 = IntToString1(mapOrg[1][0])+ "," + IntToString1(mapOrg[2][0]);
			vector<string> v1;
			vector<string> v2;
			v1.push_back(str1);
			v1.push_back(str2);
			v2.push_back(str3);
			BstNode * topNode = GetNewNode(v1,3);
			BstNode * leftChild = GetNewNode(v2,2);
			BstNode * leafOne = GetLeafNode(mapOrg[0][0]);
			BstNode * leafTwo = GetLeafNode(mapOrg[1][0]);
			BstNode * leafThree = GetLeafNode(mapOrg[2][0]);
			topNode->right = leafOne;
			topNode->left = leftChild;
			leftChild->left = leafTwo;
			leftChild->right = leafThree;

			return topNode;
		}else{

			if( xadjancy[0]==0 && xadjancy[1]==1 && xadjancy[2]==1 && xadjancy[3]== 2 && adjancy[0]==2 && adjancy[1] == 0){ //case5: xadj = {0,1,1,2} adj = {2,0}
				/*
				if(mapOrg[0][0]==23 ||mapOrg[1][0]==23 ||mapOrg[2][0]==23){
					cout << "case5"<<endl;
				}*/
				vector<string> v1;
				vector<string> v2;
				string str0 = "NoE";
				v1.push_back(str0) ; // Means that no edge separator here
				string str1 = IntToString1(mapOrg[0][0])+ "," + IntToString1(mapOrg[2][0]);
				v2.push_back(str1);
				BstNode * topNode = GetNewNode(v1,3);
				BstNode * leftChild = GetNewNode(v2,2);
				BstNode * leafOne = GetLeafNode(mapOrg[1][0]);
				BstNode * leafTwo = GetLeafNode(mapOrg[0][0]);
				BstNode * leafThree = GetLeafNode(mapOrg[2][0]);
				topNode->right = leafOne;
				topNode->left = leftChild;
				leftChild->left = leafTwo;
				leftChild->right = leafThree;

				//return NULL;
				return topNode;

			}else if(xadjancy[0]==0 && xadjancy[1]==0 && xadjancy[2]==0 && xadjancy[3]== 0){ //case6: xadj = {0,0,0,0}
				/*
				if(mapOrg[0][0]==23 ||mapOrg[1][0]==23 ||mapOrg[2][0]==23){
					cout << "case6"<<endl;
				}*/
				string str0 = "NoE";
				vector<string> v1;
				vector<string> v2;
				v1.push_back(str0) ; // Means that no edge separator here
				v2.push_back(str0);
				BstNode * topNode = GetNewNode(v1,3);
				BstNode * leftChild = GetNewNode(v2,2);
				BstNode * leafOne = GetLeafNode(mapOrg[0][0]);
				BstNode * leafTwo = GetLeafNode(mapOrg[1][0]);
				BstNode * leafThree = GetLeafNode(mapOrg[2][0]);
				topNode->right = leafOne;
				topNode->left = leftChild;
				leftChild->left = leafTwo;
				leftChild->right = leafThree;

				//return NULL;
				return topNode;

			}else if(xadjancy[0]==0 && xadjancy[1]==0 && xadjancy[2]==1 && xadjancy[3]== 2 && adjancy[0]==2 && adjancy[1] == 1){ //case7: xadj = {0,0,1,2} adj = {2,1}
				/*
				if(mapOrg[0][0]==23 ||mapOrg[1][0]==23 ||mapOrg[2][0]==23){
					cout << "case7"<<endl;
				}*/
				string str0 = "NoE";
				vector<string> v1;
				vector<string> v2;
				v1.push_back(str0) ; // Means that no edge separator here
				string str1 = IntToString1(mapOrg[1][0])+ "," + IntToString1(mapOrg[2][0]);
				v2.push_back(str1);
				BstNode * topNode = GetNewNode(v1,3);
				BstNode * leftChild = GetNewNode(v2,2);
				BstNode * leafOne = GetLeafNode(mapOrg[0][0]);
				BstNode * leafTwo = GetLeafNode(mapOrg[1][0]);
				BstNode * leafThree = GetLeafNode(mapOrg[2][0]);
				topNode->right = leafOne;
				topNode->left = leftChild;
				leftChild->left = leafTwo;
				leftChild->right = leafThree;

				//return NULL;
				return topNode;

			}else if(xadjancy[0]==0 && xadjancy[1]==1 && xadjancy[2]==2 && xadjancy[3]== 2 && adjancy[0]==1 && adjancy[1] == 0){ //case8: xadj = {0,1,2,2} adj = {1,0}
				/*
				if(mapOrg[0][0]==23 ||mapOrg[1][0]==23 ||mapOrg[2][0]==23){
					cout << "case8"<<endl;
				}*/

				vector<string> v1;
				vector<string> v2;
				string str0 = "NoE";
				v1.push_back(str0) ; // Means that no edge separator here
				string str1 = IntToString1(mapOrg[0][0])+ "," + IntToString1(mapOrg[1][0]);
				v2.push_back(str1);
				BstNode * topNode = GetNewNode(v1,3);
				BstNode * leftChild = GetNewNode(v2,2);
				BstNode * leafOne = GetLeafNode(mapOrg[2][0]);
				BstNode * leafTwo = GetLeafNode(mapOrg[0][0]);
				BstNode * leafThree = GetLeafNode(mapOrg[1][0]);
				topNode->right = leafOne;
				topNode->left = leftChild;
				leftChild->left = leafTwo;
				leftChild->right = leafThree;

				//return NULL;

				return topNode;

			}else{//caseSpecial: Unknown case
				cout<< "Unknown case!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<endl;
				cout<< xadjancy[0]<< " " <<xadjancy[1]<< " " << xadjancy[2] << " "  << xadjancy [3] <<endl;
				cout<< adjancy[0]<< " " << adjancy[1] << endl<<endl;
				return NULL;
			}
		}

	}else if (nVertex == 2){
		//cout << "nVertex == 2:  "<<endl;
		/*
		for (int i = 0 ; i < 2 ; i++){
			cout << mapOrg[i][0] << " : " <<mapOrg[i][1]<<endl;
		}*/
		//cout<< adjancy[0]<< " " << adjancy[1] <<endl;
		//string str1 = "0,1";
		string str1 = IntToString1(mapOrg[0][0])+ "," + IntToString1(mapOrg[1][0]);
		vector<string> v1;
		v1.push_back(str1);
		BstNode *leaf = GetNewNode(v1,2);
		BstNode * leafOne = GetLeafNode(mapOrg[0][0]);
		BstNode * leafTwo = GetLeafNode(mapOrg[1][0]);
		leaf->left = leafOne;
		leaf->right = leafTwo;
		return leaf;

	}else{
		cout << "HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH"<<endl;
		return NULL;
	}
}

BstNode * GenerateTree ( idx_t nVertex , idx_t *xadj, idx_t *adj , int **mapOrg){

	//termination
	if(nVertex <= 3){

		BstNode * leafNode = NULL;
		leafNode = GenerateLeaves (nVertex , xadj, adj, mapOrg );
		return leafNode;
		//return NULL;
	}

    BstNode * curr;
	//define the root
	if(nVertex == nV){
		MetisNode mynode( nVertex ,xadj,adj);
		/*
		mynode.PrintMapping();
		mynode.PrintXadj();
		mynode.PrintAdj();*/
		root = GetNewNode (mynode.EdgeSeparator , nV);
		curr =  root;
		curr->left = GenerateTree (mynode.NumberOfVL , mynode.xal , mynode.adjAftMLC , mynode.mapOrgLC);
		curr->right = GenerateTree (mynode.NumberOfVR , mynode.xar , mynode.adjAftMRC , mynode.mapOrgRC);
	}
	else{
		MetisNode mynode( nVertex ,xadj,adj, mapOrg);
		//mynode.PrintItself();
		/*
		cout<< "----------------------------------------------------------------------------------"<<endl;
		mynode.PrintMapping();
		mynode.PrintXadj();
		mynode.PrintAdj();
		*/
		curr = GetNewNode (mynode.EdgeSeparator , nVertex);
		/*
		if(mynode.EdgeSeparator.size() == 0){
			cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<endl;
			cout << mynode.NumberOfVL << " , "<< mynode.NumberOfVR <<endl;
		}*/
		curr->left = GenerateTree (mynode.NumberOfVL , mynode.xal , mynode.adjAftMLC , mynode.mapOrgLC);
		curr->right = GenerateTree (mynode.NumberOfVR , mynode.xar , mynode.adjAftMRC , mynode.mapOrgRC);
	}

	return curr;

}



void PreorderTraversal(BstNode* x){
	if(x != NULL ){
		if(x->flag == 1){


			cout << "Edge Separators: "<<endl;
			for( int i = 0; i< x->EdgeSparators.size();i++){
				cout << x->EdgeSparators[i] << endl;
			}

			PreorderTraversal(x->left);

			PreorderTraversal(x->right);
		}else{
			cout << "Node contains only one Vertex: " <<endl;
			cout<<"Vertex id: " << x->VertexId <<endl;
			cout<<"New Vertex id: " << x->NewVertexId <<endl;
		}

	}
}




void InorderTraversal(BstNode* x){
	if(x != NULL){
		if(x->flag == 1){
			InorderTraversal(x->left);
			for( int i = 0; i< x->EdgeSparators.size();i++){
				cout <<  x->EdgeSparators[i] << endl;
			}
			InorderTraversal(x->right);

		}else{
			cout << "Node contains only one Vertex: " <<endl;
			cout<<"Vertex id: " << x->VertexId <<endl;
			cout<<"New Vertex id: " << x->NewVertexId <<endl;
		}
	}
}

void RenumberByInorderTraversal(BstNode* x){

	if(x != NULL){
		RenumberByInorderTraversal(x->left);

		if(x->flag == 0){

			x->NewVertexId = InorderTraversalVID;

			mapAfterRenumber[x->VertexId] = InorderTraversalVID;
			InorderTraversalVID++;

			//cout << x->VertexId <<endl;

		}

		RenumberByInorderTraversal(x->right);
	}

}

void FindNeighbour (BstNode *x){
	if(x != NULL){
		if(x->flag == 1){
			if(x->EdgeSparators.size() != 0 ){
				if( x->EdgeSparators[0] != "NoE"){
					for( int i=0; i<x->EdgeSparators.size(); i++){
						int vertexA , vertexB = -1;
						int index = x->EdgeSparators[i].find(",");
						vertexA = stoi(x->EdgeSparators[i].substr(0,index));
						vertexB = stoi(x->EdgeSparators[i].substr(index+1,x->EdgeSparators[i].size()));
						int mapA = mapAfterRenumber[vertexA];
						int mapB = mapAfterRenumber[vertexB];
						nlns.AddItem(mapB , mapA );
						nlns.AddItem(mapA , mapB );
					}
				}
			}
			FindNeighbour(x->left);
			FindNeighbour(x->right);
		}
	}
}

void FormAdjTable(NeighbourListNonSorted NLS ){
    for(int i=0; i<nV; i++){
    	negativeDiff[i] = false;
    }

	for(int i = 0; i<NLS.tableSize ;i++){

		vector<phsim::BitString::Word> curVertexAdjList;
    	int v0 = i;
    	int v1 = NLS.sortedNeighbourTable[i][0];

    	string gammaCode = "";

		if( v0 > v1){ // Which means v0-v1 is less than 0
			//gammaCode = EncodingEliasGamma( v0-v1);
			negativeDiff[i] = true;
			curVertexAdjList.push_back((int)(v0-v1));

		}else{
			//gammaCode = EncodingEliasGamma( v1-v0);

			curVertexAdjList.push_back((int)(v1-v0));

		}
		//AdjList.push_back(gammaCode);

		for ( int j=0 ; j<NLS.NumberOfItemsInIndex(i) -1 ; j++){
			v0 = v1;
			v1 = NLS.sortedNeighbourTable[i][j+1];

			string gammaCode1 = "";
			curVertexAdjList.push_back((int)(v1-v0));
			/*
			if( v0 > v1){ // Which means v0-v1 is less than 0
				//gammaCode1 = EncodingEliasGamma( v0-v1);
				inputWV.push_back((int)(v0-v1));

			}else{
				//gammaCode1 = EncodingEliasGamma( v1-v0);
				inputWV.push_back((int)(v1-v0));
				//cout<<"211"<<endl;
			}*/

    	}
		offsetIndex.push_back(NLS.NumberOfItemsInIndex(i));
		inputWV.push_back(curVertexAdjList);
		//adjTable.push_back(AdjList);
		//cout << endl;
    }
    //cout << input.size();

}


void PreorderTraCountLeaf(BstNode* x){
	if(x != NULL ){
		if(x->flag == 1){

			CountLeaves (x , x->leaves);

			PreorderTraCountLeaf(x->left);

			PreorderTraCountLeaf(x->right);
		}

	}
}
void PreorderTraversalCheckLeaf(BstNode* x){
	if(x != NULL ){
		if(x->flag == 1){

			cout << "Vertex: "<<endl;
			for( int i = 0; i< x->leaves.size();i++){
				cout << x->leaves[i] << endl;
			}
			cout <<"Vertex num : " << x->vertexNum <<endl;
			PreorderTraversalCheckLeaf(x->left);

			PreorderTraversalCheckLeaf(x->right);
		}

	}
}
void CountLeaves ( BstNode * x , vector<int>&Vset){
	if(x != NULL){
		if(x->flag == 1){
			CountLeaves(x->left , Vset);

			CountLeaves(x->right, Vset);

		}else{
			Vset.push_back(x->VertexId);
		}
	}
}

void PreorderTraFormEdgeSet(BstNode* x , vector <string> set){
	if(x->left != NULL && x->right != NULL){
		if(x->flag == 1){
			for( int i=0 ; i<set.size(); i++){
				x->EdgeSet.push_back(set[i]);
			}
			for( int i=0 ; i<x->EdgeSparators.size(); i++){
				x->EdgeSet.push_back(x->EdgeSparators[i]);
			}

			PreorderTraFormEdgeSet(x->left , x->EdgeSet);

			PreorderTraFormEdgeSet(x->right , x->EdgeSet);
		}

	}
}

void PreorderTraversalCheckEdgeSet(BstNode* x){
	if(x != NULL ){
		if(x->flag == 1){

			cout << "EdgeSet: "<<endl;
			for( int i = 0; i< x->EdgeSet.size();i++){
				cout << x->EdgeSet[i] << endl;
			}


			PreorderTraversalCheckEdgeSet(x->left);

			PreorderTraversalCheckEdgeSet(x->right);
		}

	}
}

void ChildFliping( BstNode * x){
	if ( x->left != NULL && x->right != NULL){
		if ( x->left->flag != 0 && x->right->flag != 0 ){
			int scoreL = 0;
			int scoreR = 0;
			int numL = x->left->vertexNum ;
			int Vnum = x->vertexNum ;

			for ( int i = 0; i< x->EdgeSet.size() ; i++){
				int vertexA , vertexB = -1;
				int index = x->EdgeSet[i].find(",");
				vertexA = stoi(x->EdgeSet[i].substr(0,index));
				vertexB = stoi(x->EdgeSet[i].substr(index+1,x->EdgeSet[i].size()));
				//cout << vertexA << "    " <<vertexB <<endl;

				for( int j =0; j< numL;j++){
					if (x->leaves[j] == vertexA || x->leaves[j] == vertexB){
						scoreL ++ ;
					}
				}
				for( int j=numL; j<Vnum ; j++ ){
					if (x->leaves[j] == vertexA || x->leaves[j] == vertexB){
						scoreR ++ ;
					}
				}

			}

			//cout << "scoreL :" <<scoreL << "  scoreR :  " <<scoreR <<endl;

			if (scoreL < scoreR){

				BstNode * temp = NULL;
				temp = x->left;
				x->left = x->right;
				x->right = temp;
			}
			ChildFliping(x -> left);
			ChildFliping(x -> right);

		}
	}
}



int MetisUsage(){

    idx_t nVertices = 6;
    idx_t nEdges    = 5;
    idx_t nWeights  = 1;
    idx_t nParts    = 2;

    idx_t objval;
    idx_t part[nVertices];


    // Indexes of starting points in adjacent array
    idx_t xadj[nVertices+1] = {0,2,4,5,8,9,10};

    // Adjacent vertices in consecutive index order
    idx_t adjncy[2 * nEdges] = {2,3,3,4,0,5,0,1,1,3};

    // Weights of vertices
    // if all weights are equal then can be set to NULL
    idx_t vwgt[nVertices * nWeights];


    int ret = METIS_PartGraphRecursive(&nVertices,& nWeights, xadj, adjncy,
     				       NULL, NULL, NULL, &nParts, NULL,
     				       NULL, NULL, &objval, part);

    /*
    int ret = METIS_PartGraphKway(&nVertices,& nWeights, xadj, adjncy,
				       NULL, NULL, NULL, &nParts, NULL,
				       NULL, NULL, &objval, part);
	*/
    //std::cout << ret << std::endl;
    cout<< "------------------------------------------" <<endl;
    for(unsigned part_i = 0; part_i < nVertices; part_i++){
	std::cout << part_i << " " << part[part_i] << std::endl;
    }
    cout<< "------------------------------------------" <<endl;
    MetisNode mynode( nVertices ,xadj,adjncy);
    return 0;
}



