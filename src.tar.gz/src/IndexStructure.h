/*
 * IndexStructure.h
 *
 *  Created on: Apr 13, 2017
 *      Author: xiangzhang
 */


#ifndef INDEXSTRUCTURE_H
#define INDEXSTRUCTURE_H

#include <iostream>
#include <vector>
#include <string>
#include <bitset>
#include <math.h>

class IndexStructure{


public:
	IndexStructure();
	void CountDITotalBits();
	void BuildSemiDIndex();
	int IntegerBitLength(int num);
	void indirectIndex ();
	std::vector <unsigned int> directIndex;
	std::vector <int> semiDIFW;
	std::vector < std::vector <std::bitset<10>  >  > semiDISW;
	std::vector <unsigned int * > semiDISWSub;
	int ** block;
	int * subBlock;
	unsigned long directIndexTotalBit;
	unsigned int semiDIflag;
	unsigned int vNum;
	unsigned blockNum;
	unsigned blockVNum;
	unsigned subBlockLength;
	std::vector <std::bitset<14> > bitVofEachBlock;  // Number of vertex in each block on 4elt.graph
	//std::vector <std::bitset<18> > bitVofEachBlock;	 // Number of vertex in each block on feocean.graph
	//std::vector <std::bitset<18> > bitVofEachBlock;	 // Number of vertex in each block on m14b.graph

	std::vector < std::vector< std::vector<unsigned int>  >  > indrectIndex;

};


IndexStructure::IndexStructure( ){
	this->block = NULL;
	this->subBlock = NULL;
	this->directIndexTotalBit = 0;
	this->semiDIflag = 0;
	this->vNum = 0;
	this->blockVNum=0;
	this->blockNum=0;
	this->subBlockLength = 0;
}

void IndexStructure::CountDITotalBits(){
	unsigned long sum=0;
	for (int i=0; i<this->directIndex.size() ;i++){
		sum+= IntegerBitLength(this->directIndex[i]);
	}
	this->directIndexTotalBit = sum;
	this->vNum = this->directIndex.size();
}

void IndexStructure::BuildSemiDIndex(){
	std::vector <int> tempOffsetSet;
	for (int i=0; i<this->directIndex.size();i++){
		if (i%4 == 0){
			this->semiDIFW.push_back(this->directIndex[i]);
		}else{
			tempOffsetSet.push_back(this->directIndex[i]);
		}
	}
	for (int i=0 ; i<tempOffsetSet.size()/3; i++){
		int len1 = IntegerBitLength( tempOffsetSet[i*3]);
		int len2 = IntegerBitLength( tempOffsetSet[i*3+1]);
		int len3 = IntegerBitLength( tempOffsetSet[i*3+2]);
		std::vector< bitset<10> > secWord;
		if ( len3 <= 11){

			std::bitset<10> n1(tempOffsetSet[i*3]);
			std::bitset<10> n2(tempOffsetSet[i*3+1]);
			std::bitset<10> n3(tempOffsetSet[i*3+2]);
			secWord.push_back(n1);
			secWord.push_back(n2);
			secWord.push_back(n3);
			this->semiDISW.push_back(secWord);
			this->semiDIflag = (i+1)*4;
		}else{
			unsigned int secSubWord[3] = {tempOffsetSet[i*3], tempOffsetSet[i*3+1],tempOffsetSet[i*3+2]};
			this->semiDISWSub.push_back(secSubWord);
		}
	}
	int rest = tempOffsetSet.size()%3 ;
	unsigned int *tail = new unsigned int [rest];
	for (int i=0; i<rest; i++){
		tail[i] = tempOffsetSet[tempOffsetSet.size()/3*3 + i];
	}
	this->semiDISWSub.push_back(tail);


}
int IndexStructure::IntegerBitLength(int num) {
	int length = 0;
	while (num > 0)
		num >>= 1, ++length;
	return length;
}
void IndexStructure::indirectIndex(){
	this->blockVNum = std::ceil(std::log2(this->vNum));
	this->blockNum = std::ceil(this->vNum*1.0/this->blockVNum);
	this->subBlockLength = 16* this->blockVNum;

	std::vector <unsigned int> temp;
	std::vector < std::vector<unsigned int> > subblock;

	for (int i = 0; i < this->blockNum -1 ; i++) {
		int offsetCountforSubblock = 0;
		for (int j = 0; j < this->blockVNum; j++) {
			temp.push_back(this->directIndex[i]);
			offsetCountforSubblock += this->directIndex[i * this->blockVNum + j];

			if (offsetCountforSubblock > this->subBlockLength) {
				subblock.push_back(temp);
				temp.clear();
				offsetCountforSubblock = 0;
			}
		}

	}

}
#endif
