/*
 * NeighbourListNonSorted.h
 *
 *  Created on: Dec 28, 2016
 *      Author: xiangzhang
 */


#ifndef NEIGHBOURLISTNONSORTED_H_
#define NEIGHBOURLISTNONSORTED_H_



#include <cstdlib>
#include <iostream>
#include <string>
#include <algorithm>
#include <string>

using namespace std;

struct NeighbourEntry{
		int VertexId;

		NeighbourEntry* next;

};

class NeighbourListNonSorted{

public:
	NeighbourListNonSorted();


	static const int tableSize = 15606; // table size of 4elt graph
	//static const int tableSize = 214765; // table size of m14b graph
	//static const int tableSize = 143437; // table size of feocean graph
	//static const int tableSize = 15; // table size of hyper-small mesh graph

	void AddItem( int Vid, int index);
	void SortItself();
	void PrintTable();
	void PrintItemsInIndex(int index);
	int NumberOfItemsInIndex(int index);


	int** sortedNeighbourTable;

	NeighbourEntry* Table[tableSize];

};
NeighbourListNonSorted::NeighbourListNonSorted(){
	for(int i=0 ; i<tableSize ; i++){
		Table[i] = new NeighbourEntry;
		Table[i]->VertexId = -1;
		Table[i]->next = NULL;
	}
	sortedNeighbourTable = NULL;
}

void NeighbourListNonSorted::AddItem(int vid, int index){


	if(Table[index]->VertexId == -1){

		Table[index]->VertexId = vid;

	}else{
		NeighbourEntry* Ptr = Table[index];

		NeighbourEntry* n = new NeighbourEntry;
		n->VertexId = vid;
		n->next = NULL;

		while(Ptr->next != NULL){
			Ptr = Ptr->next;
		}
		Ptr->next = n;
	}
}

void NeighbourListNonSorted::PrintItemsInIndex(int index){
	NeighbourEntry* Ptr = Table[index];
	if(Ptr->VertexId == -1){
		cout<<"index = "<< index <<" is empty "<<endl;
	}else{
		cout<<"index "<< index << " contains the following items\n" ;
		while(Ptr != NULL){
			cout << "------------\n";
			cout <<Ptr->VertexId <<endl;

			Ptr = Ptr->next;
		}
	}
}
int NeighbourListNonSorted::NumberOfItemsInIndex(int index){
	int count = 0;
	if(Table[index]->VertexId == -1){
		return count;
	}else{
		count++;
		NeighbourEntry* Ptr = Table[index];
		while(Ptr->next != NULL){
			count++;
			Ptr = Ptr->next;
		}
	}
	return count;
}

void NeighbourListNonSorted::SortItself(){

	sortedNeighbourTable = new int*[tableSize];

	for(int i=0; i<tableSize ; i++){
		sortedNeighbourTable[i] = new int [ NumberOfItemsInIndex(i)];
	}

	for(int i=0; i<tableSize ; i++){

		int tempArr [NumberOfItemsInIndex(i)];
		NeighbourEntry* Ptr = Table[i];
		for(int j=0; j<NumberOfItemsInIndex(i); j++){
			//cout << Ptr->VertexId<< " * " ;
			tempArr [j] = Ptr->VertexId;
			if(Ptr->next != NULL){

				Ptr = Ptr->next;
			}
		}
		sort(tempArr, tempArr + NumberOfItemsInIndex(i) );
		for (int k=0; k<NumberOfItemsInIndex(i) ; k++){
			sortedNeighbourTable[i][k] = tempArr[k];
		}
	}

}
#endif
